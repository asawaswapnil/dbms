<?php 

echo '<meta http-equiv="Refresh" content="0;url=http://localhost/ampps/index.php?act=secure">';

unlink('index.php');

?>