<html>
	<head>
		<title>
			Students data - INFSCI 2710
		</title>
	</head>
	<body>
		<?php
			$servername = "localhost";
			$username = "root";
			$password = "mysql";
			$db = "yelp_db";

			// Create connection
			$conn = new mysqli($servername, $username, $password, $db);

			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			}
			echo "<p><font color=\"red\">Connected successfully</font></p>";

			//echo "<a href='http://localhost/.html'>Add new student</a>";
			// Run sql
			$sql = "call MostLikedTipForHealthNCareInMyPostalCode()";
			$result = $conn->query($sql);

			echo '<table border=1>
    <tr>
		<th>name</th>
        <th>address</th>
        <th>category</th>
		<th>text</th>
		<th>likes</th>
    </tr>';		

			while($row = $result->fetch_assoc()) {
				echo "<tr>";
				echo "<td><a href='http://localhost/HW4/ShowShopDetails.php?name=" . $row["name"] ."'>". $row["name"]. "</td>";
				echo "<td>" . $row["address"] . "</td>";
				echo "<td>" . $row["category"] . "</td>";
				echo "<td>" . $row["text"] . "</td>";
				echo "<td>" . $row["likes"] . "</td>";
				echo "</tr>";
			}
			echo "</table>";
			echo 'total number of rows '. $result->num_rows;

			
			$result->free();

			// Close connection
			mysqli_close($conn);
		?>
	</body>
</html>
