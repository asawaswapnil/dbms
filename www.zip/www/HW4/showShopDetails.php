<html>
	<head>
		<title>
			Welcome to INFSCI 2710
		</title>
	</head>
	<body>

		<?php
			$servername = "localhost";
			$username = "root";
			$password = "mysql";
      $database = "yelp_db";

			$bname = $_REQUEST["name"];

			if(is_null($bname) || $bname == "")
			{
				die("Please specify business name. <a href='http://localhost/selectStudent.php'>Check result");
			}

			// Create connection
			$conn = new mysqli($servername, $username, $password, $database);

			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			}
			echo "<p><font color=\"red\">Connected successfully</font></p>";
			// Run a sql
      echo $bname;
			$sql = "select * from business where name = '" . $bname . "';";
			$result = $conn->query($sql);
			if($result != TRUE)
			{echo "<p>0 results!</p>";}
      else 
  //       {while ($row = $result->fetch_assoc()) {
  // echo "<tr>";
  // foreach( $row as $key=>$value)

  // { echo "<td> $key:</td>";
  //   echo "<td>$value</td>";
  // }
  // echo "</tr>";
  // } }


// }}
  { echo '<table border=1>
    <tr>
    <th>name</th>
    <th>neighbourhood</th>
    <th>address</th>
    <th>postal_code</th>
    <th>city</th>
    <th>latitude</th>
    <th>longitude</th>
    <th>stars</th>
    <th>review_count</th>
    <th>is_open</th>
    </tr>';   

      while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["name"] . "</td>";
        echo "<td>" . $row["neighbourhood"] . "</td>";
        echo "<td>" . $row["address"] . "</td>";
        echo "<td>" . $row["postal_code"] . "</td>";
        echo "<td>" . $row["city"] . "</td>";
        echo "<td>" . $row["state"] . "</td>";
        echo "<td>" . $row["latitude"] . "</td>";
        echo "<td>" . $row["longitude"] . "</td>";
        echo "<td>" . $row["stars"] . "</td>";
        echo "<td>" . $row["review_count"] . "</td>";
        echo "<td>" . $row["is_open"] . "</td>";
        echo "</tr>";
      }
      echo "</table>";
      // echo 'total number of rows '. $result->num_rows;


      //    while($row = $result->fetch_assoc()) {
      //     echo $row["name"] ;}
      // }
      echo 'total number of rows '. $result->num_rows;}

      // Close connection
      mysqli_close($conn);
    ?>
  </body>
</html>