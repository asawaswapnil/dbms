<html>
	<head>
		<title>
			Welcome to INFSCI 2710
		</title>
	</head>
	<body>
		<?php
			$servername = "localhost";
			$username = "root";
			$password = "mysql";

			// Create connection
			$conn = new mysqli($servername, $username, $password);

			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			} 
			echo "<p><font color=\"red\">Connected successfully</font></p>";
			
			// Run a sql
			$sql = "show databases;";
			$result = $conn->query($sql);
			while($row = $result->fetch_assoc()) {
				echo $row["Database"]."<br/>";
			}
			$sql1="USE ye";
			$result1=$conn->query($sql1);
			$sql15="show tables";
			$result15=$conn->query($sql15);
			$sql2 = "SELECT * from student";
			$result2= $conn->query($sql2);
			echo "<a href=http://localhost/HW1/addStudent.html> Add students</a><br>"	;	
			if ($result2->num_rows > 0) {
    // output data of each row
echo '<table>
    <tr>
		<th>Delete</th>
        <th>ID</th>
        <th>Name</th>
		<th>Dept_Name</th>
		<th>tot_credits</th>
    </tr>';			
while ($row = $result2->fetch_assoc()) {
	echo "<tr>";
	echo "<td> <a href='http://localhost/HW1/deleteStudent.php?ID=".$row[ID]."'>Delete</a>"; 
	echo "<td> <a href='http://localhost/HW1/editStudent.php?ID=".$row[ID]."'>Edit</a>"; 
	foreach( $row as $key=>$value)
	{	echo "<td>$value</td>";
	}
	echo "</tr>";
	} }else {
				echo "0 results";

}
	echo 'total number of students '. $result2->num_rows;
	$sql3='select avg(tot_cred) average from student';
	$result3=$conn->query($sql3);
	while ($row3 = mysqli_fetch_array($result3))
		echo "<br> average credits: ".$row3["average"]."<br>";
	
	

			$result->free();

			// Close connection
			mysqli_close($conn);
		?>
	</body>
</html>
