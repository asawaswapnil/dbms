<html>
<body>
<?php 
$servername = "localhost";
			$username = "root";
			$password = "mysql";

			// Create connection
			$conn = new mysqli($servername, $username, $password);

			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			} 
			echo "<p><font color=\"red\">Connected successfully</font></p>";

			// Run a sql
			$sql = "show databases;";
			$result = $conn->query($sql);
			$sql1="USE lab";
			$result1=$conn->query($sql1);
			$sql15="show tables";
			$result15=$conn->query($sql15);
			$sql2 = "SELECT * from student";
			$result2= $conn->query($sql2);	
		#	$sql4 = "insert into student values ('1', 'Swao', 'Physics', '46')";
		#$result3= $conn->query($sql4);	
		$id=$_POST[ID];
		$nam=$_POST[name];
		$dept=$_POST[department];
		$cred=$_POST[credit];
		echo $nam, $dept,$cred, $id;
		$sql4 = "insert into student values( '$id', '$nam','$dept','$cred')";
		$result4= $conn->query($sql4);	
		if($result4){echo "Addition successful!";}
		else{echo "Something wrong!";}
		?>
		<a href="selectStudent.php">check the table</a>


</body>
</html>