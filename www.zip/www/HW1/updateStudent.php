
<html>

<body>
<?php $servername = "localhost";
			$username = "root";
			$password = "mysql";

			// Create connection
			$conn = new mysqli($servername, $username, $password);

			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			} 
			$sql = "show databases;";
			$result = $conn->query($sql);
			$sql1="USE lab";
			$result1=$conn->query($sql1);
			$sql15="show tables";
			$result15=$conn->query($sql15);
			$sql2 = "SELECT * from student";
			$result2= $conn->query($sql2);	
			
			$sql4 = "update student set name='".$_GET['name']."',dept_name='".$_GET['department']."',tot_cred='".$_GET[credit]."' where ID='".$_GET['ID']."'";
			$result4= $conn->query($sql4);	
			if($result4){echo "Editing successful!";}
			else{echo "Something wrong!";}
			?>
		
		<a href="selectStudent.php" >check the table</a>
</body>
</html>