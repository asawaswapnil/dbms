<html>
	<head>
		<title>
			Welcome to INFSCI 2710
		</title>
	</head>
	<body>

		<?php
			$servername = "localhost";
			$username = "root";
			$password = "mysql";
      $db = "lab";

			$sid = $_REQUEST["id"];

			$tryagain = "<a href='http://localhost/addStudent.html'>Try again</a>";
			if(is_null($sid) || $sid == "")
			{
				die("Please specify student ID. " . $tryagain);
			}

			// Create connection
			$conn = new mysqli($servername, $username, $password);

			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			}
			echo "<p><font color=\"red\">Connected successfully</font></p>";

			// Run a sql
			$sql = "delete from lab.student where ID = " . $sid . ";";
			$result = $conn->query($sql);
			if($result === TRUE)
			{
				echo "<p>Record deleted successfully!";
			}
			else
			{
				echo "<p>Error while deleting record!";
			}
      echo "<br>";
			echo "<a href='http://localhost/selectStudent.php'>Check result</a>";
      mysqli_close($conn);
		?>
	</body>
</html>
