<html>
	<head>
		<title>
			Welcome to INFSCI 2710
		</title>
	</head>
	<body>

		<?php
			$servername = "localhost";
			$username = "root";
			$password = "mysql";
      $db = "lab";

			$sid = $_POST["sid"];
			$sname = $_POST["sname"];
			$dept = $_POST["dept"];
			$credit = $_POST["credit"];

			$tryagain = "<a href='http://localhost/addStudent.html'>Try again</a>";
			if(is_null($sid) || $sid == "")
			{
				die("Please specify student ID. " . $tryagain);
			}
			if(is_null($sname))
			{
				die("Please specify student name. " . $tryagain);
			}
			if(!is_null($credit) && $credit < 0)
			{
				die("Please specify valid credit value. " . $tryagain);
			}

			// Create connection
			$conn = new mysqli($servername, $username, $password, $db);

			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			}
			echo "<p><font color=\"red\">Connected successfully</font></p>";

      $sname = str_replace("'", "''", $sname);
			// Run a sql
      $sql = "update student set name = \"" . $sname
        . "\", dept_name = '" . $dept . "', tot_cred = " . $credit
        . " where ID = " . $sid . ";";

      if($conn->query($sql) === TRUE)
			{
				echo "<p>Record updated successfully!</p>";
			}
			else
			{
				echo "<p>Error while updating record!</p>";
			}
      echo "<br/>";
			echo "<a href='http://localhost/selectStudent.php'>Check result</a>";
      mysqli_close($conn);
		?>
	</body>
</html>
