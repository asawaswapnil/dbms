<html>
	<head>
		<title>
			Welcome to INFSCI 2710
		</title>
	</head>
	<body>

		<?php
			$servername = "localhost";
			$username = "root";
			$password = "mysql";
      $database = "lab";

			$sid = $_REQUEST["id"];

			if(is_null($sid) || $sid == "")
			{
				die("Please specify student ID. <a href='http://localhost/selectStudent.php'>Check result");
			}

			// Create connection
			$conn = new mysqli($servername, $username, $password, $database);

			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			}
			echo "<p><font color=\"red\">Connected successfully</font></p>";

			// Run a sql
			$sql = "select * from student where ID = '" . $sid . "';";
			$result = $conn->query($sql);
			if($result != TRUE)
				echo "<p>Error while fetching specified record!</p>";

      if($row = $result->fetch_assoc())
      {
      ?>
        Add new student:
    		<form method="POST" action="updateStudent.php">
    		<br/>
    		<input type="hidden" name="sid" value="<?php echo $row['ID']; ?>"/>
    		<br/>
    		Name: <input type="text" name="sname" value="<?php echo $row['name']; ?>"/>
    		<br/>
    		Department:
    		<select name="dept" id="deptcmb">
    			<option value="Biology">Biology</option>
    			<option value="Comp. Sci.">Computer Science</option>
    			<option value="Elec. Eng.">Electrical Engineering</option>
    			<option value="Finance">Finance</option>
    			<option value="History">History</option>
    			<option value="Music">Music</option>
    			<option value="Physics">Physics</option>
    		</select>
    		<br/>
    		Credit: <input type="text" name="credit" value="<?php echo $row['tot_cred'] ?>"/>
    		<br/>
    		<input type="submit" value="Submit">
      <?php
      }
		?>
	</body>
  <script>
    document.getElementById('deptcmb').value = '<?php echo $row['dept_name']; ?>'
  </script>
</html>
