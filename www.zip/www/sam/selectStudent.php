<html>
	<head>
		<title>
			Students data - INFSCI 2710
		</title>
	</head>
	<body>
		<?php
			$servername = "localhost";
			$username = "root";
			$password = "mysql";
			$db = "lab";

			// Create connection
			$conn = new mysqli($servername, $username, $password, $db);

			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			}
			echo "<p><font color=\"red\">Connected successfully</font></p>";

			echo "<a href='http://localhost/addStudent.html'>Add new student</a>";
			// Run sql
			$sql = "select * from student;";
			$result = $conn->query($sql);
			echo "<table border=1>";
			echo "<tr>";
			echo "<th>Delete</th><th>Edit</th><th>ID</th><th>Name</th><th>Subject"
				. "</th><th>Grade</th>";
			echo "</tr>";

			while($row = $result->fetch_assoc()) {
				echo "<tr>";
				echo "<td><a href='http://localhost/deleteStudent.php?id=" . $row["ID"]
					. "'>Delete</a></td>";
				echo "<td><a href='http://localhost/editStudent.php?id=" . $row["ID"]
						. "'>Edit</a></td>";
				echo "<td>" . $row["ID"] . "</td>";
				echo "<td>" . $row["name"] . "</td>";
				echo "<td>" . $row["dept_name"] . "</td>";
				echo "<td>" . $row["tot_cred"] . "</td>";
				echo "</tr>";
			}
			echo "</table>";

			// compute count and average credit of Students
			$sql = "select count(*) as cnt, avg(tot_cred) as avrg from lab.student;";
			$result = $conn->query($sql);

			if($row = $result->fetch_assoc())
			{
				echo "<p>Total number of students: " . $row["cnt"] . "</p>";
				echo "<p>Average grade of students: " . $row["avrg"] . "</p>";
			}

			$result->free();

			// Close connection
			mysqli_close($conn);
		?>
	</body>
</html>
