<html>
	<head>
		<title>
			Welcome to INFSCI 2710
		</title>
	</head>
	<body>

		<?php
			$servername = "localhost";
			$username = "root";
			$password = "mysql";
      $db = "lab";

			$sid = $_POST["sid"];
			$sname = $_POST["sname"];
			$dept = $_POST["dept"];
			$credit = $_POST["credit"];

      if(is_null($sid) || $sid == "")
			{
				die("Please specify student ID. <a href='http://localhost/selectStudent.php'>Check result");
			}

			$tryagain = "<a href='http://localhost/addStudent.html'>Try again</a>";

			// Create connection
			$conn = new mysqli($servername, $username, $password, $db);

			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			}
			echo "<p><font color=\"red\">Connected successfully</font></p>";

			$sname = str_replace("'", "''", $sname);
			// Run a sql
			$sql = "insert into student(ID,name,dept_name,tot_cred) values('".
				$sid . "','" . $sname . "','" . $dept . "','" . $credit . "')";
			$result = $conn->query($sql);
			if($result == TRUE)
			{
				echo "<p>Record inserted successfully! <a href='http://localhost/addStudent.html'>Add another</a></p>";
			}
			else
			{
				echo "<p>Error while inserting resord! <a href='http://localhost/addStudent.html'>Try again</a></p>";
			}

			echo "<a href='http://localhost/selectStudent.php'>Check result</a>"
		?>
	</body>
</html>
